#!/usr/bin/python

import sys
from time import sleep

in_file = sys.argv[1]
filelen = 5000
with open(in_file, 'r') as f:
    content = f.read().splitlines()
    f.close()

print("[+] Read {} lines.".format(len(content)))
basename, extention = in_file.split('.')

filecount = 1
for i in range(0, (len(content) - 1), filelen):
    names = content[i:((i+filelen) - 1)]
    current_file = "{}_{}.{}".format(basename, filecount, extention)
    print("Dumping {} -> {} into {}\n".format(i,((i+filelen) - 1), current_file))
    filecount += 1
    with open(current_file, 'w') as o:
        for name in names:
            o.write("{}\n".format(name))
        o.close() 
